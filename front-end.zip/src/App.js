import "./App.css";
import HomePage from "./views/index.jsx";

function App() {
  return <HomePage />;
}

export default App;
